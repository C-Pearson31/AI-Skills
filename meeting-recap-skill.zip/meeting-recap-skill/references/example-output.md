# Example Output — Meeting Recap Skill

Annotated example of a well-formatted meeting recap. Use as a calibration target when uncertain about format, section depth, or citation placement.

---

**Meeting:** Workflow & RACI Review — Ticket Readiness Process
**Date:** Thursday, March 5, 2026
**Attendees:** Chris, Eliana
**Duration:** 30 minutes

---

## 1) Executive Outcomes (top 3 to 5)

- Outcome: Agreement to revise the workflow and RACI for ticket readiness and acceptance criteria, focusing on clearer responsibilities and validation steps. (Chris, 00:20:00)
  - Why selected: Stakeholder alignment | Ensures all team members understand their roles and the process for moving tickets forward. (Chris, 00:20:00)
  - Evidence: Chris and Eliana discussed operationalizing the process, emphasizing the need for both product team and developer validation of acceptance criteria. (Chris, 00:40:00)

- Outcome: Decision to consolidate roles in the RACI, treating all developers the same and simplifying QA and integration distinctions. (Chris, 00:50:00)
  - Why selected: Work unblocker | Reduces confusion and streamlines responsibility assignment across the team. (Chris, 00:50:00)
  - Evidence: Chris advised using "assigned developer" and "QA" instead of separating integration and listing individual names. (Chris, 00:50:00)

- Outcome: Plan to create a visual workflow mapping statuses and responsibilities for each stage. (Chris, 00:54:00)
  - Why selected: Stakeholder alignment | Provides clarity on expectations at each process stage for all participants. (Chris, 00:54:00)
  - Evidence: Chris suggested illustrating the process with a workflow diagram showing what is expected at each status. (Chris, 00:54:00)

---

## 2) Decisions (explicitly made)

- Decision: The product team must validate acceptance criteria, either by authoring or approving AI-generated criteria, before development proceeds. (Chris, 00:45:00)
  - Reason: Ensures requirements are clear and testable, reducing ambiguity and rework. (Chris, 00:45:00)
  - Impact: Adds a formal review step for acceptance criteria by the product team. (Chris, 00:45:00)

- Decision: RACI will use general roles ("assigned developer," "QA") instead of individual names or integration-specific columns. (Chris, 00:50:00)
  - Reason: Simplifies the matrix and applies responsibilities consistently across all developers. (Chris, 00:50:00)
  - Impact: All developers and QA are treated uniformly in the process. (Chris, 00:50:00)

---

## 3) Action Items (commitments)

- Action: Revise the workflow and RACI proposal to reflect feedback, including clearer role definitions and process steps. (Eliana, 00:55:00)
  - Owner: Eliana.
  - Due: TBD. Reason: no specific date mentioned in transcript.
  - Done means: Updated documents shared with Chris for review and containing all feedback-driven changes.
  - Dependencies: Chris for review and further feedback.
  - Evidence: (Eliana, 00:55:00)

- Action: Review and provide feedback on the revised workflow and RACI. (Chris, 00:55:00)
  - Owner: Chris.
  - Due: TBD. Reason: dependent on Eliana's revision timeline.
  - Done means: Feedback delivered to Eliana in writing or via follow-up meeting.
  - Dependencies: Eliana's revised document.
  - Evidence: (Chris, 00:55:00)

- Action: Schedule a follow-up meeting on Monday or Tuesday to review Eliana's revisions. (Eliana, 00:57:00)
  - Owner: Eliana.
  - Due: Monday or Tuesday of the following week.
  - Done means: Meeting invite sent and accepted by both parties.
  - Dependencies: None.
  - Evidence: (Eliana, 00:57:00)

---

## 4) Risks and Blockers

- Risk/Blocker: Workflow revision may not be finalized before the next project begins, leaving process ambiguity in place. (Chris, 00:20:00)
  - Severity: Medium.
  - Severity justification: Process gaps during active project work create inconsistent ticket quality and developer confusion. (Chris, 00:20:00)
  - Impact: Teams may continue operating without clear acceptance criteria standards. (Chris, 00:20:00)
  - Likelihood: Medium.
  - Mitigation: Both parties agreed to finalize deliverables within the month. (Chris, 00:57:00)
  - Owner: Eliana.

---

## 5) Open Questions (unresolved)

- Question: How should the visual workflow (chevrons or similar) be created and who is responsible for producing it? (Chris, 00:54:00)
  - Why open: Chris suggested the concept but no owner or timeline was assigned during the meeting. (Chris, 00:54:00)
  - Owner: Unknown. Reason: not assigned in transcript.
  - Needed by: TBD. Reason: tied to overall workflow revision timeline.

---

## 6) Dependencies and Handoffs

- Dependency/Handoff: Chris. (Eliana, 00:55:00)
  - Need: Review and feedback on revised workflow and RACI document. (Eliana, 00:55:00)
  - By: TBD. Reason: no date specified.
  - Why it matters: Eliana cannot finalize the proposal without Chris's sign-off. (Eliana, 00:55:00)

---

## 7) Parking Lot (deferred topics)

- Deferred topic: Specific tooling for visual workflow creation (e.g., Lucidchart, Miro, Visio). (Chris, 00:54:00)
  - Deferred because: needs follow-up work — no tool was selected or discussed during the meeting. (Chris, 00:54:00)
  - Next step: Eliana to include tool recommendation in revised proposal. (Chris, 00:54:00)

---

## 8) Next Checkpoint

- Next checkpoint: Monday or Tuesday of the following week.
- Purpose: Review Eliana's revised workflow proposal and RACI diagram.
- Preparation required: Eliana to complete and share revised documents before the meeting.

---

## Annotation Notes (for skill calibration — do not include in real output)

**What this example demonstrates:**

- Outcomes describe RESULTS ("Agreement to revise..."), not activities ("Discussed the workflow...")
- Each Executive Outcome has a labeled "Why selected" — the label comes first, then the justification
- Decisions include the word "must" or "will" — they were explicitly confirmed, not just discussed
- Action items have all four components every time — Owner, Due (with reason if TBD), Done means, Dependencies
- Risks include Severity justification as a full sentence with impact + likelihood reasoning
- Open Questions are truly unresolved — the answer was not given in the transcript
- "None captured." would appear exactly like that with no explanation if a section had no content
- Section 8 uses the minimal form when only the date/purpose are known
