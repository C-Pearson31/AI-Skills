# Output Rules — Meeting Recap Skill

Complete formatting specification, citation rules, and quality guards. Read this before writing any section output.

---

## Citation Rules

**When to cite:**
- Every Outcome, Decision, Action Item, Risk/Blocker, Open Question, Dependency, Deferred Topic, and Next Checkpoint detail that contains substantive content MUST have at least one citation.
- Use at most 2 citations per bullet.

**Citation format:** `(Speaker, HH:MM:SS)`

**When NOT to cite:**
- "None captured." lines — no citation
- Unknown reason phrases — no citation
- Meeting metadata (title, date, attendees)

---

## Silence Rule (CRITICAL FOR READABILITY)

If a section has no content, output ONLY:
- None captured.

**Do not:**
- Explain why there is no content
- Mention that you scanned the transcript
- Add timestamps to "None captured." lines
- Add qualifiers like "No risks were identified in this meeting."

---

## Unknown Rule (MINIMAL, NO NOISE)

If a field value is not determinable from the transcript, write:
`Unknown. Reason: <short phrase>.`

Examples:
- `Owner: Unknown. Reason: not assigned in transcript.`
- `Due: Unknown. Reason: no date mentioned.`

Do NOT include timestamps on Unknown reason phrases.

---

## Quality Rules

**Outcomes** are results, not activities. Ask: did this materially change understanding, direction, risk, or next steps? If not, it is not an Executive Outcome.

**Decisions** require explicit confirmation. The following phrases qualify:
- "we will do X"
- "agreed to X"
- "decided on X"
- "approved X"
- "we're going with X"

The following do NOT qualify as Decisions:
- "we should probably..."
- "I think we'll..."
- "let's consider..."
- "we talked about X"

**Action items** are incomplete without all four components: Owner, Due, Done means, Dependencies. If any are missing from the transcript, use TBD or Unknown with a reason phrase.

---

## Section Formatting Specifications

### 1) Executive Outcomes (top 3 to 5)

```
- Outcome: <result, not activity>. (Speaker, HH:MM:SS)
  - Why selected: <label + short justification: Decision impact | Work unblocker | Risk reduction | Major scope change | Stakeholder alignment | Deadline driver>. (Speaker, HH:MM:SS)
  - Evidence: <1 short paraphrased supporting phrase>. (Speaker, HH:MM:SS)
```

If none: `- None captured.`

---

### 2) Decisions (explicitly made)

```
- Decision: <what was decided>. (Speaker, HH:MM:SS)
  - Reason: <why it was made>. (Speaker, HH:MM:SS)
  - Impact: <what changes now>. (Speaker, HH:MM:SS)
```

If none: `- None captured.`

---

### 3) Action Items (commitments)

**Do NOT use a markdown table.** Use this exact list format:

```
- Action: <verb + object>. (Speaker, HH:MM:SS)
  - Owner: <name or Unknown>. If Unknown: Reason: <short phrase>.
  - Due: <date/time or TBD>. If TBD: Reason: <short phrase>.
  - Done means: <clear completion criteria>.
  - Dependencies: <people/teams/systems or None>.
  - Evidence: (Speaker, HH:MM:SS)
```

If none: `- None captured.`

---

### 4) Risks and Blockers

```
- Risk/Blocker: <what could go wrong or what is blocking>. (Speaker, HH:MM:SS)
  - Severity: Low | Medium | High.
  - Severity justification: <one sentence: impact + likelihood based on transcript>. (Speaker, HH:MM:SS)
  - Impact: <what breaks or degrades>. (Speaker, HH:MM:SS)
  - Likelihood: <Low | Medium | High | Unknown>. If Unknown: Reason: not discussed.
  - Mitigation: <next step>. (Speaker, HH:MM:SS)
  - Owner: <name or Unknown>. If Unknown: Reason: <short phrase>.
```

If none: `- None captured.`

---

### 5) Open Questions (unresolved)

```
- Question: <what is unknown>. (Speaker, HH:MM:SS)
  - Why open: <short reason>. (Speaker, HH:MM:SS)
  - Owner: <name or Unknown>. If Unknown: Reason: <short phrase>.
  - Needed by: <date or TBD>. If TBD: Reason: <short phrase>.
```

If none: `- None captured.`

---

### 6) Dependencies and Handoffs

```
- Dependency/Handoff: <team/system/person>. (Speaker, HH:MM:SS)
  - Need: <what is required>. (Speaker, HH:MM:SS)
  - By: <date or TBD>. If TBD: Reason: <short phrase>.
  - Why it matters: <one sentence>. (Speaker, HH:MM:SS)
```

If none: `- None captured.`

---

### 7) Parking Lot (deferred topics)

```
- Deferred topic: <topic>. (Speaker, HH:MM:SS)
  - Deferred because: <out of scope | timeboxed | missing info | wrong attendees | needs follow-up work | waiting on dependency>. (Speaker, HH:MM:SS)
  - Next step: <what happens instead>. (Speaker, HH:MM:SS)
```

If none: `- None captured.`

---

### 8) Next Checkpoint

Only include details if explicitly stated in the transcript. If not stated, use Unknown with reason phrase.

```
- Next checkpoint: <date/time or Unknown>. If Unknown: Reason: not mentioned.
- Purpose: <purpose or Unknown>. If Unknown: Reason: not mentioned.
- Preparation required: <prep steps or Unknown>. If Unknown: Reason: not mentioned.
```

If all three fields are Unknown:
```
- Next checkpoint: Unknown. Reason: not mentioned.
```

---

## Final Check (Run Before Delivering Output)

- [ ] All 8 sections present
- [ ] No duplicate bullets across sections
- [ ] No filler sentences ("As discussed...", "The team covered...")
- [ ] Citations present on all substantive items
- [ ] "None captured." lines have no extra explanation
- [ ] Decisions passed the explicit confirmation test
- [ ] Action items have all four components
- [ ] No invented details
