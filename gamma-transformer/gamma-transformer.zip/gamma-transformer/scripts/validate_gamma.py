#!/usr/bin/env python3
"""
Gamma Markdown Format Validator

Validates that markdown output meets Gamma.app format requirements.
"""

import re
import sys
from pathlib import Path


def validate_gamma_markdown(content: str) -> tuple[bool, list[str]]:
    """
    Validate Gamma markdown format.
    
    Returns:
        (is_valid, list_of_issues)
    """
    issues = []
    
    # Split into slides
    slides = content.split('---')
    
    # Remove any header content before first slide
    if slides and not slides[0].strip().startswith(('#', '[')):
        slides = slides[1:]
    
    if len(slides) < 2:
        issues.append("ERROR: No slide separators (---) found. Must have at least 2 slides.")
        return False, issues
    
    for i, slide in enumerate(slides, 1):
        slide_content = slide.strip()
        
        if not slide_content:
            continue
            
        # Check for title
        has_title = (
            slide_content.startswith('[') or 
            slide_content.startswith('# ') or
            '**Gamma Settings' in slide_content or
            'BACKUP SLIDES' in slide_content or
            '**Transformation Complete' in slide_content
        )
        
        if not has_title and i <= len(slides) - 1:  # Exclude last summary slide
            issues.append(f"WARNING: Slide {i} may be missing a title")
        
        # Count words (exclude visual hints and AI instructions)
        text_content = re.sub(r'Visual:.*?(\n|$)', '', slide_content)
        text_content = re.sub(r'Layout:.*?(\n|$)', '', text_content)
        text_content = re.sub(r'Emphasis:.*?(\n|$)', '', text_content)
        text_content = re.sub(r'AI instruction:.*?(\n|$)', '', text_content)
        
        words = len(text_content.split())
        
        if words > 75:
            issues.append(f"WARNING: Slide {i} has {words} words (recommend <50, max 75)")
        
        # Check bullet depth
        lines = slide_content.split('\n')
        for line in lines:
            indent_level = len(line) - len(line.lstrip())
            if line.strip().startswith('-'):
                # Count leading spaces/tabs
                if indent_level > 4:  # More than 2 levels (4 spaces = 2 levels)
                    issues.append(f"WARNING: Slide {i} has bullets nested >2 levels deep")
                    break
    
    # Check for common mistakes
    if '```' in content and '---' not in content.split('```')[0]:
        issues.append("WARNING: No slide separators found before code blocks")
    
    # Check for proper emoji usage (not excessive)
    emoji_pattern = r'[\U0001F300-\U0001F9FF]'
    for i, slide in enumerate(slides, 1):
        emoji_count = len(re.findall(emoji_pattern, slide))
        if emoji_count > 5:
            issues.append(f"INFO: Slide {i} has {emoji_count} emojis (recommend max 3)")
    
    is_valid = not any(issue.startswith("ERROR") for issue in issues)
    
    return is_valid, issues


def validate_file(filepath: str):
    """Validate a Gamma markdown file."""
    path = Path(filepath)
    
    if not path.exists():
        print(f"❌ File not found: {filepath}")
        return False
    
    content = path.read_text(encoding='utf-8')
    
    is_valid, issues = validate_gamma_markdown(content)
    
    print(f"\n{'='*60}")
    print(f"Validating: {filepath}")
    print(f"{'='*60}\n")
    
    if is_valid and not issues:
        print("✅ All checks passed! Markdown is Gamma-ready.\n")
        return True
    
    if is_valid:
        print("✅ Format is valid, but there are some recommendations:\n")
    else:
        print("❌ Format has errors that must be fixed:\n")
    
    for issue in issues:
        if issue.startswith("ERROR"):
            print(f"  ❌ {issue}")
        elif issue.startswith("WARNING"):
            print(f"  ⚠️  {issue}")
        else:
            print(f"  ℹ️  {issue}")
    
    print()
    return is_valid


def main():
    if len(sys.argv) < 2:
        print("Usage: python validate_gamma.py <markdown_file>")
        print("\nValidates Gamma.app markdown format including:")
        print("  - Slide separators (---)")
        print("  - Slide titles")
        print("  - Word count per slide")
        print("  - Bullet nesting depth")
        print("  - Emoji usage")
        sys.exit(1)
    
    filepath = sys.argv[1]
    is_valid = validate_file(filepath)
    
    sys.exit(0 if is_valid else 1)


if __name__ == "__main__":
    main()
