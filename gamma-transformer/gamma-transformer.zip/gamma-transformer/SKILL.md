---
name: gamma-transformer
description: Transforms complete slide deck specifications into Gamma.app-optimized markdown format. Use when users need to convert presentation content (with slide titles, content, visual descriptions, speaker notes, and design specs) into markdown that's ready to paste into Gamma.app's "Paste in text" creation mode. Triggers include requests like "transform for Gamma", "optimize for Gamma.app", "convert slides to Gamma format", or when users mention having presentation content to use in Gamma.
---

# Gamma Transformer

## Overview

Transform fully-specified slide decks into Gamma.app-optimized markdown that produces high-quality presentations when pasted into Gamma's "Paste in text" mode. This skill handles the specialized formatting requirements, content optimization, and structural transformations needed for Gamma's AI presentation engine.

## Transformation Workflow

Follow these steps sequentially when transforming presentations:

### 1. Pre-Process Input

Analyze the provided slide deck:
- Count total slides
- Identify slides needing split (>75 words of content)
- Identify slides to merge (similar topics, minimal content)
- Flag critical metrics/data to preserve exactly
- Note any visual patterns or design requirements

### 2. Apply Gamma Format Rules

Transform each slide using these strict requirements:

**Slide Separator:**
```
---
```
(Exactly three dashes on own line between every slide - CRITICAL)

**Slide Title:**
```
[Title Here]
```
or
```
# Title Here
```

**Content Hierarchy:**
```
Primary headline or statement

Supporting detail
- Bullet point 1
- Bullet point 2
  - Sub-bullet (maximum 2 levels)

Additional paragraph if needed
```

**Visual Hints (inline, concise):**
```
Visual: [Brief description - max 15 words]
Layout: [Structure - e.g., "two-column comparison"]
Emphasis: [What to highlight - e.g., "large 77% callout"]
```

### 3. Content Optimization Rules

**Text Density:**
- Maximum 50 words per slide (Gamma performs best with sparse text)
- If original has 100+ words → Split into 2 slides
- Priority: Headlines > Data > Supporting bullets

**Bullet Depth:**
- Maximum 2 levels deep
- Flatten or split slides if original has 3+ levels

**Numbers & Metrics:**
- Preserve exact percentages, time savings, costs
- Format prominently: `🎯 **83% Time Savings**`
- Use emoji + bold for key metrics

**Strategic Emoji Usage:**
- 🎯 = Goals, targets, key points
- ⚡ = Fast, efficient, action items
- 📊 = Data, metrics, analytics
- ✅ = Benefits, success, completion
- ⚠️ = Warnings, concerns, risks
- 💡 = Ideas, insights, innovations
- 🔧 = Tools, implementation
- 📅 = Timeline, dates, schedule
- 💰 = Cost, budget, ROI

### 4. Visual Instruction Condensation

Transform detailed visual specs into brief inline hints:

**Formula:** [Layout type] + [Key visual elements] + [Emphasis] + [Color notes if critical]

**Example transformation:**

Before (too detailed):
```
Two-column layout with divider, left uses red/yellow,
right uses green/blue, large callout box at bottom,
clock icons on metrics, 77% in 48pt bold accent color
```

After (optimized):
```
Visual: Two-column before/after. Clock icons on metrics. 
Large 77% callout. Contrasting colors (red → green).
```

### 5. Speaker Notes Handling

Extract value from speaker notes without including them directly:

**Extract and integrate:**
- Critical statistics → Include in slide content
- Powerful audience questions → Add to slide if essential
- Emphasis cues → Convert to bold/emoji in content

**Discard:**
- Timing notes
- Delivery cues
- Transition phrases

### 6. Structure Output

Begin with:
```markdown
# [PRESENTATION TITLE]

**Gamma Settings Recommendation:**
- Format: 16:9 (Traditional) [or Fluid/4:3]
- Text per card: Concise [or Moderate/Detailed]
- Image source: AI-generated [or Stock/None]
- Theme: [Modern/Minimal/Professional/Bold]

**Master AI Instructions:**
[2-3 sentences of overall design guidance]

---
```

Then provide each slide with proper formatting.

End with:
```markdown
---

**Transformation Complete**
- Total slides: [X]
- Estimated time: [Y minutes at 2.5-3 min/slide]
- Key optimizations: [Summary of major changes]
```

## Quality Verification

Before delivering output, verify:

✅ Every slide ends with `---` (except final slide)
✅ No slide exceeds 50 words
✅ All key metrics preserved with exact numbers
✅ Maximum 2 bullet levels anywhere
✅ Emoji markers used strategically (not excessively)
✅ Visual hints are concise (<15 words each)
✅ Content maintains logical flow
✅ Slide count appropriate for presentation time

## Additional Resources

For detailed formatting specifications and examples, see:
- `references/format-spec.md` - Complete Gamma markdown rules and edge cases
- `references/transformation-examples.md` - Before/after transformation examples
- `scripts/validate_gamma.py` - Optional validation script for output format
