# Gamma Format Specification

## Critical Formatting Rules

### Slide Separators

**CRITICAL:** Use exactly three dashes on their own line:
```
---
```

This is how Gamma recognizes slide breaks. Anything else will fail.

### Title Formats

Two options (be consistent within a deck):

**Option 1: Brackets**
```
[Slide Title Here]
```

**Option 2: H1 Markdown**
```
# Slide Title Here
```

### Content Structure Best Practices

**Optimal hierarchy:**
```
Strong opening statement or headline

Supporting sentence providing context
- Bullet point with specific detail
- Bullet point with specific detail
  - Sub-bullet (use sparingly)

Closing statement or metric if needed
```

**Maximum depth:** 2 bullet levels

**Avoid:**
- Long paragraphs (>40 words)
- More than 5 bullets per slide
- Nested bullets beyond 2 levels

## Visual Hint Patterns

Keep visual hints brief and actionable. Gamma's AI interprets these to generate layouts.

### Layout Types

**Two-column comparison:**
```
Visual: Two-column layout. Left = before, right = after.
```

**Matrix/Grid:**
```
Visual: 2x2 matrix. Four quadrants with clear labels.
```

**Timeline:**
```
Visual: Horizontal timeline. Four phases with progressive intensity.
```

**Data visualization:**
```
Visual: Bar chart showing comparison. Emphasize highest value.
```

**Decision framework:**
```
Visual: Numbered decision boxes (1-2-3). Include checkboxes.
```

### Emphasis Patterns

**Callout boxes:**
```
Emphasis: Large callout box for 77% metric.
```

**Color coding:**
```
Visual: Use contrasting colors (red vs. green) to show improvement.
```

**Icon integration:**
```
Visual: Clock icons next to each time metric.
```

## Special Content Types

### Comparison Slides

Format as before → after:

```
[Transformation Results]

Traditional Approach → AI-Enhanced Approach

Manual entry: 6 hrs/week → 30 min/week
Report generation: 4 hrs/week → 1 hr/week
Email responses: 5 hrs/week → 2 hrs/week

🎯 Result: 15 hours → 3.5 hours = **77% TIME SAVINGS**

Visual: Two-column before/after. Clock icons. Large callout for 77%.

---
```

### Decision/Action Slides

Always number sequential items:

```
[3 Decisions We Need Today]

1️⃣ **Commit to 2-Day Training**
   January 15-16, all staff participate

2️⃣ **Designate Department Champions**
   One person per department by December 20

3️⃣ **Approve 90-Day Support Package**
   Monthly check-ins + implementation assistance

Visual: Numbered framework. Decision boxes with commitment element.

---
```

### Data-Heavy Slides

Keep numbers prominent:

```
[ROI from Similar Organizations]

**Healthcare Org**
📊 67% reduction in admin overhead
⚡ 12 hours saved per week per person
✅ ROI in 6 weeks

**Municipal Government**
⚡ Report time: 8 hours → 45 min (94% faster)
📊 94% accuracy improvement
✅ Live in 30 days

Visual: Two-column case studies. Stat cards with large numbers.

---
```

### Timeline Slides

Use clear phase structure:

```
[12-Week Implementation Timeline]

📅 **Phase 1: Discovery** (Weeks 1-2)
→ Stakeholder interviews, baseline metrics

📅 **Phase 2: Training** (Week 3)
→ 2-day intensive, hands-on practice

📅 **Phase 3: Deploy** (Weeks 4-8)
→ Phased rollout, real-time support

📅 **Phase 4: Optimize** (Weeks 9-12)
→ Measure results, certify champions

Visual: Gantt-style timeline. Highlight key milestones.

---
```

## Text Density Guidelines

**Ideal:** 25-40 words per slide
**Maximum:** 50 words per slide
**Action:** If >50 words, split into 2 slides

**Word count example (38 words, optimal):**
```
[The AI Opportunity]

Stop spending 15 hours weekly on repetitive work. 
AI automation reduces this to 3.5 hours—a 77% time savings.

What would your team do with an extra 11.5 hours per week?

Visual: Before/after comparison with time visualization.
```

## Emoji Usage Strategy

Use emojis as **visual anchors**, not decoration.

**Effective patterns:**

**Data/metrics:** 📊 📈 💰
```
📊 67% improvement in efficiency
```

**Time/speed:** ⚡ 📅 ⏱️
```
⚡ 8 hours → 45 minutes
```

**Success/completion:** ✅ 🎯 ⭐
```
✅ ROI achieved in 6 weeks
```

**Process/action:** 🔧 ⚙️ 🛠️
```
🔧 Implementation: Weeks 4-8
```

**Warning/attention:** ⚠️ 🚨 ⚡
```
⚠️ Data privacy protocols required
```

**Ideas/insights:** 💡 🧠 💭
```
💡 Quick win opportunity: Email automation
```

**Limit:** 2-3 emojis per slide maximum

## Edge Cases

### Slides with Multiple Concepts

❌ **Don't combine:**
```
[AI Benefits and Implementation Plan and Timeline and Budget]
```

✅ **Split into focused slides:**
```
[AI Benefits: The ROI Story]
---
[Implementation Plan]
---
[12-Week Timeline]
---
[Investment & Budget]
```

### Complex Visuals/Charts

When original calls for data visualization, provide data in structured format:

```
[Revenue Growth Comparison]

📊 **2023 vs 2024 Performance**

Q1: $2.3M → $3.1M (+35%)
Q2: $2.7M → $3.4M (+26%)
Q3: $3.1M → $3.9M (+26%)
Q4: $3.5M → $4.2M (+20%)

Visual: Bar chart or line graph. Emphasize upward trend and Q1 growth.

AI instruction: Generate chart visualization showing quarterly comparison.

---
```

### Backup/Appendix Slides

Clearly label at the end:

```
---

# BACKUP SLIDES

[Technical Details]

Content...

---

[Additional Data]

Content...

---
```

## Common Mistakes to Avoid

❌ **Forgetting slide separator**
```
[Slide 1]
Content...
[Slide 2]  ← Missing --- separator
```

✅ **Always separate:**
```
[Slide 1]
Content...

---

[Slide 2]
```

❌ **Overly detailed visual instructions**
```
Visual: Two-column layout with 1px divider line in #CCCCCC, 
left column has red (#FF0000) heading with Helvetica Neue 24pt 
bold font, gradient background from #FFF to #EEE at 45° angle...
```

✅ **Concise and actionable:**
```
Visual: Two-column layout. Red heading on left, green on right.
```

❌ **Including speaker notes directly**
```
[Opening line] "Welcome everyone to today's presentation..."
[PAUSE here for 3 seconds]
[Ask question] "What challenges are you facing?"
```

✅ **Extract the value:**
```
What challenges are you currently facing with manual workflows?
```

❌ **Vague metrics**
```
Significant improvement in efficiency
```

✅ **Specific numbers:**
```
📊 67% improvement in efficiency
```
