---
name: slide-deck
description: >
  Generates professional Microsoft PowerPoint (.pptx) decks using a mandatory
  ASCII blueprint + per-slide wireframes + theme approval phase before any file
  is built. Use when the user asks to "build a deck," "create a PowerPoint,"
  "make a presentation," "generate slides," or any request that results in a
  .pptx file. Fully separate from the gamma-transformer skill — different tool,
  different process, different output. Always read /mnt/skills/public/pptx/SKILL.md
  before generating the file.
---

# Slide Deck Skill

## Overview

This skill builds professional PowerPoint decks in four phases:

1. **Blueprint** — Overview table showing slide number, title, layout type, and content
   approach. Presented first for structural approval.
2. **Per-Slide Wireframes** — ASCII drawings that visually picture the spatial layout of
   every non-trivial slide, including SmartArt shape recommendations. Presented immediately
   after blueprint approval.
3. **Theme Recommendation** — Color palette, typography, and visual motif. Presented
   alongside wireframes.
4. **File Generation** — Build the `.pptx` using the pptx skill once everything is approved.

**The blueprint and wireframes are mandatory.** Do not generate content or build a file
until the user approves (or explicitly says "skip blueprint"). Structural corrections cost
nothing before generation and everything after.

---

## Phase 1: Overview Blueprint

### Purpose

The blueprint is a navigation index — a quick-scan table that lets the user see the full
deck structure at a glance and request structural changes (reorder, split, merge, swap
layouts) before wireframes are drawn.

### Format

```
+====================================================================+
|  DECK BLUEPRINT -- [Presentation Title]                            |
|  Total slides: X  |  Audience: [inferred]  |  Est. build: ~Y min  |
+====================================================================+

 #  | Slide Title                        | Layout Type    | Content Approach
----|------------------------------------+----------------+--------------------------------
 1  | [Title]                            | TITLE          | Deck name + subtitle/tagline
 2  | [Slide 2 Title]                    | BIG STATEMENT  | Single stat or provocative hook
 3  | [Slide 3 Title]                    | TWO-COLUMN     | Before/after contrast
 4  | [Slide 4 Title]                    | PROCESS        | 3-step linear flow
 5  | [Slide 5 Title]                    | DATA CALLOUT   | Key metric + 2 supporting points
 6  | [Slide 6 Title]                    | FULL IMAGE     | Visual metaphor + caption
 7  | [Slide 7 Title]                    | COMPARISON     | Side-by-side case stats
 8  | [Slide 8 Title]                    | BULLETS        | 4-point diagnostic list
 9  | [Slide 9 Title]                    | TIMELINE       | 4-phase milestone view
10  | [Slide 10 Title]                   | CLOSING CTA    | Single ask, white space dominant

Layout variety check:  PASSED  (no 3 consecutive identical layouts)
Bullet density check:  PASSED  (BULLETS = 10% of deck, under 30% cap)
Title length check:    PASSED  (all titles <= 8 words)
Idea-per-slide check:  PASSED  (no titles contain "and" joining two concepts)

Reply with:
  "Approved" to proceed to wireframes
  Specific edits (e.g., "Swap slides 4 and 6" / "Change slide 3 to TIMELINE")
  "Skip blueprint" to bypass all planning phases and go straight to build
```

### Validation Checks (Run Before Showing Blueprint)

- Flag any slide title over 8 words and shorten proactively
- Flag any title containing "and" joining two distinct concepts and suggest a split
- Flag 3+ consecutive slides with the same layout type and reorder before presenting
- Flag if BULLETS layout exceeds 30% of total slides and redistribute
- Flag if deck has 8+ slides with zero FULL IMAGE or BIG STATEMENT and add one

---

## Phase 2: Per-Slide Wireframes + Theme

Once the blueprint overview is approved, present two things together in a single response:

1. **A per-slide ASCII wireframe** for every non-trivial slide
2. **The theme recommendation block**

Ask for a single approval on both before proceeding to build.

### Which Slides Get Wireframes

| Layout Type   | Wireframe Required | Reason |
|---------------|--------------------|--------|
| TITLE         | No                 | Simple: deck name + subtitle, no spatial complexity |
| BULLETS       | No                 | Simple: headline + stacked bullet list |
| CLOSING CTA   | No                 | Simple: single action statement, white space |
| BIG STATEMENT | Yes                | Spatial composition matters for impact |
| TWO-COLUMN    | Yes                | Column balance and label placement |
| PROCESS       | Yes                | SmartArt shape drives meaning |
| TIMELINE      | Yes                | Milestone spacing and node placement |
| DATA CALLOUT  | Yes                | Hero number scale and support placement |
| FULL IMAGE    | Yes                | Image zone, text overlay position, contrast |
| COMPARISON    | Yes                | Column structure and parallel alignment |

---

### Wireframe Templates by Layout Type

Use the appropriate template below as the model for each non-trivial slide. Populate it
with the actual content from the deck. Do not show blank templates — every wireframe
must contain the real slide content (or clearly labeled placeholders when content is
not yet specified).

---

#### BIG STATEMENT

Use when the goal is one idea landing with full force. Centered composition, white space
does the heavy lifting. No bullets, no lists.

```
+----------------------------------------------------------+
|  [Slide Title - max 8 words]                             |
+----------------------------------------------------------+
|                                                          |
|                                                          |
|   "The most important sentence on this slide goes        |
|    here — centered, large, nothing competing with it"    |
|                 [40-44pt, centered]                      |
|                                                          |
|          Subline or stat in smaller text below           |
|               [20-24pt, centered, muted]                 |
|                                                          |
|                                                          |
+----------------------------------------------------------+
  Composition: Centered vertical/horizontal
  White space:  Top 20% and bottom 20% intentionally empty
```

---

#### TWO-COLUMN

Use for before/after, problem/solution, old way/new way contrasts. Column labels anchor
the comparison. Points must be parallel in structure and count.

```
+----------------------------------------------------------+
|  [Slide Title]                                           |
+----------------------------------------------------------+
|                         |                               |
|  [ LEFT LABEL ]         |  [ RIGHT LABEL ]              |
|  ~~~~~~~~~~~~~~~~~~~~~~ |  ~~~~~~~~~~~~~~~~~~~~~~       |
|                         |                               |
|  • Left point one       |  • Right point one            |
|  • Left point two       |  • Right point two            |
|  • Left point three     |  • Right point three          |
|                         |                               |
|  [optional icon/image]  |  [optional icon/image]        |
|                         |                               |
+----------------------------------------------------------+
  Divider:     Vertical line or white space gap (not a hard border)
  Balance:     Equal number of points per column — no exceptions
  Label style: Bold, accent color, 18-20pt
```

---

#### PROCESS — Linear (use when steps happen in sequence, left to right)

```
+----------------------------------------------------------+
|  [Slide Title]                                           |
+----------------------------------------------------------+
|                                                          |
|  +----------+      +----------+      +----------+       |
|  |          |  ->  |          |  ->  |          |       |
|  | [Step 1] |      | [Step 2] |      | [Step 3] |       |
|  | subtitle |      | subtitle |      | subtitle |       |
|  +----------+      +----------+      +----------+       |
|                                                          |
|  [optional brief footer note if context needed]         |
|                                                          |
+----------------------------------------------------------+
  SmartArt:  Chevron or Arrow Chain (PowerPoint: Process > Chevron Process)
  Use when:  Steps must happen in order, linear progression
  Nodes:     3-5 max; split to second slide if more needed
```

#### PROCESS — Circular (use when steps repeat or feed back into each other)

```
+----------------------------------------------------------+
|  [Slide Title]                                           |
+----------------------------------------------------------+
|                                                          |
|                  +----------+                            |
|                  | [Step 1] |                            |
|                 /            \                           |
|    +----------+                +----------+             |
|    | [Step 4] |                | [Step 2] |             |
|    +----------+                +----------+             |
|                 \            /                           |
|                  +----------+                            |
|                  | [Step 3] |                            |
|                  +----------+                            |
|                                                          |
+----------------------------------------------------------+
  SmartArt:  Basic Cycle or Continuous Cycle
             (PowerPoint: Cycle > Basic Cycle)
  Use when:  Process is iterative, ongoing, or loops back
```

#### PROCESS — Funnel (use when steps narrow, filter, or qualify)

```
+----------------------------------------------------------+
|  [Slide Title]                                           |
+----------------------------------------------------------+
|                                                          |
|  ==========================================             |
|       [Stage 1: broadest input/category]                |
|    ======================================               |
|         [Stage 2: filtered/refined]                     |
|      ================================                   |
|           [Stage 3: narrowed]                           |
|        ============================                     |
|              [Stage 4: output]                          |
|           ======================                        |
|                                                         |
+----------------------------------------------------------+
  SmartArt:  Funnel (PowerPoint: Relationship > Funnel)
  Use when:  Volume decreases at each stage (leads, screening, qualification)
```

#### PROCESS — Staircase (use when steps build on each other progressively)

```
+----------------------------------------------------------+
|  [Slide Title]                                           |
+----------------------------------------------------------+
|                                              +-------+  |
|                                 +-------+   | Step 4|  |
|                    +-------+   | Step 3|   |       |  |
|       +-------+   | Step 2|   |       |   |       |  |
|       | Step 1|   |       |   |       |   |       |  |
|       +-------+   +-------+   +-------+   +-------+  |
|                                                        |
+----------------------------------------------------------+
  SmartArt:  Ascending Picture Accent or Step Up Process
             (PowerPoint: Process > Step Up Process)
  Use when:  Maturity model, capability levels, building momentum
```

---

#### TIMELINE

Use for implementation phases, project milestones, or chronological sequences.
Time flows left to right. Each node gets a label, date, and one-line deliverable.

```
+----------------------------------------------------------+
|  [Slide Title]                                           |
+----------------------------------------------------------+
|                                                          |
|  [Phase 1]    [Phase 2]    [Phase 3]    [Phase 4]       |
|  [Date/Wk]    [Date/Wk]    [Date/Wk]    [Date/Wk]      |
|      |             |            |            |          |
|  ====o=============o============o============o====>     |
|      |             |            |            |          |
|  Deliverable   Deliverable  Deliverable  Deliverable    |
|  [one line]    [one line]   [one line]   [one line]     |
|                                                         |
+----------------------------------------------------------+
  SmartArt:  Basic Timeline or Circle Accent Timeline
             (PowerPoint: Process > Basic Timeline)
  Nodes:     4-5 max per slide; split if more needed
  Dates:     Above the line; deliverables below
```

---

#### DATA CALLOUT

The number is the hero. Everything else is context. No competing headlines.
Number should feel like it owns the slide.

```
+----------------------------------------------------------+
|  [Slide Title - frames what the number means]            |
+----------------------------------------------------------+
|                                                          |
|               +-----------------+                        |
|               |                 |                        |
|               |      57%        |  <- 60-72pt, accent    |
|               |                 |       color            |
|               +-----------------+                        |
|                                                          |
|       of employees already use AI at work                |
|            [context line, 18pt, centered]                |
|                                                          |
|   • Supporting point one (max 8 words)                   |
|   • Supporting point two (max 8 words)                   |
|                                                          |
+----------------------------------------------------------+
  Number:     Dominant — 3x larger than any other text on slide
  Source:     Include citation below context line in 10pt if applicable
  Max points: 2 support bullets only — more dilutes the hero
```

---

#### FULL IMAGE

Image occupies 80-100% of the slide canvas. Text is overlaid, not beside.
The image carries the emotional or conceptual weight — text anchors it.

```
+----------------------------------------------------------+
|:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::|
|:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::|
|::::::  IMAGE FILLS ENTIRE SLIDE CANVAS  ::::::::::::::::::|
|::  [describe subject: e.g., aerial view of empty office]::|
|:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::|
|:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::|
|                                                          |
|  [Slide Title overlaid — high contrast against image]    |
|  [Optional 6-word subline]                               |
|                                                          |
+----------------------------------------------------------+
  Image subject:   [Describe what the image should show — be specific]
  Text position:   Bottom-left (default) / Center / Bottom-right
  Text contrast:   Dark overlay band behind text if image is busy
  Text size:       Title 36-44pt, subline 20-24pt
  Rule:            If text is hard to read, the overlay band is mandatory
```

---

#### COMPARISON

Two options shown side by side with equal weight. Parallel structure is mandatory —
same number of comparison points on each side, same grammatical form.

```
+----------------------------------------------------------+
|  [Slide Title]                                           |
+----------------------------------------------------------+
|                          |                              |
|  +--------------------+  |  +--------------------+     |
|  |  [ OPTION A ]      |  |  |  [ OPTION B ]      |     |
|  | (or BEFORE / OLD)  |  |  | (or AFTER / NEW)   |     |
|  +--------------------+  |  +--------------------+     |
|  | • Comparison pt 1  |  |  | • Comparison pt 1  |     |
|  | • Comparison pt 2  |  |  | • Comparison pt 2  |     |
|  | • Comparison pt 3  |  |  | • Comparison pt 3  |     |
|  +--------------------+  |  +--------------------+     |
|                          |                              |
+----------------------------------------------------------+
  Divider:    Vertical accent-color line at center
  Labels:     Bold, accent color; clearly name what each column represents
  Balance:    Exactly equal points per side — no exceptions
  Optional:   Winner indicator (checkmark, highlight, color) on preferred side
```

---

### Theme Recommendation Block

Present immediately below the last wireframe, before asking for approval.

**Selection logic:**

| Context Signals                         | Recommended Theme                      |
|-----------------------------------------|----------------------------------------|
| Corporate / executive / board           | Midnight Executive or Charcoal Minimal |
| Healthcare, education, nonprofit        | Teal Trust or Sage Calm                |
| Sales, pitch, competitive               | Cherry Bold or Coral Energy            |
| Financial, legal, professional services | Midnight Executive or Berry & Cream    |
| Technology, innovation, AI              | Ocean Gradient or Charcoal Minimal     |
| Sustainability, environment, wellness   | Forest & Moss or Sage Calm             |
| General business (no strong signal)     | Teal Trust or Charcoal Minimal         |

**Theme block format:**

```
+====================================================================+
|  RECOMMENDED THEME                                                 |
+====================================================================+

Theme Name:   [e.g., Midnight Executive]
Rationale:    [1 sentence -- why this fits the audience and topic]

  Primary    [######]  #XXXXXX  ([name])   -- backgrounds, dominant surfaces
  Secondary  [######]  #XXXXXX  ([name])   -- content areas, supporting elements
  Accent     [######]  #XXXXXX  ([name])   -- headlines, callouts, key numbers

Typography:
  Headers    [Font] Bold, 36-44pt
  Body       [Font], 14-16pt
  Captions   [Font] Light, 10-12pt

Visual motif: [1-2 sentences: repeating design element + dark/light structure.
               e.g., "Accent-color horizontal rule below every slide title.
               Dark backgrounds on TITLE and CLOSING CTA; light on all content
               slides (sandwich structure)."]

Alternatives if you prefer a different feel:
  - [Theme B] -- [one-line vibe difference]
  - [Theme C] -- [one-line vibe difference]

Reply with "Approved" or specify changes before the build begins.
```

**Available palettes:**

| Theme Name         | Primary            | Secondary           | Accent           |
|--------------------|--------------------|---------------------|------------------|
| Midnight Executive | #1E2761 navy       | #CADCFC ice blue    | #FFFFFF white    |
| Forest & Moss      | #2C5F2D forest     | #97BC62 moss        | #F5F5F5 cream    |
| Coral Energy       | #F96167 coral      | #F9E795 gold        | #2F3C7E navy     |
| Warm Terracotta    | #B85042 terracotta | #E7E8D1 sand        | #A7BEAE sage     |
| Ocean Gradient     | #065A82 deep blue  | #1C7293 teal        | #21295C midnight |
| Charcoal Minimal   | #36454F charcoal   | #F2F2F2 off-white   | #212121 black    |
| Teal Trust         | #028090 teal       | #00A896 seafoam     | #02C39A mint     |
| Berry & Cream      | #6D2E46 berry      | #A26769 dusty rose  | #ECE2D0 cream    |
| Sage Calm          | #84B59F sage       | #69A297 eucalyptus  | #50808E slate    |
| Cherry Bold        | #990011 cherry     | #FCF6F5 off-white   | #2F3C7E navy     |

**Typography pairings (safe system fonts):**

| Header       | Body          | Character          |
|--------------|---------------|--------------------|
| Georgia      | Calibri       | Classic authority  |
| Arial Black  | Arial         | Bold impact        |
| Calibri      | Calibri Light | Clean modern       |
| Cambria      | Calibri       | Formal credibility |
| Trebuchet MS | Calibri       | Approachable modern|

---

## Phase 3: Content Rules

Apply silently once blueprint, wireframes, and theme are approved. Do not narrate
these to the user — just enforce them.

### Text Density

- Target: 25-40 words of text per slide
- Maximum: 50 words per slide (hard limit)
- If a slide exceeds 50 words: split into two slides and note the split in build summary
- Exception: User-specified leave-behind or reading decks — must be explicitly stated

### Bullet Rules

- Maximum 5 bullets per slide
- Maximum 5-6 words per bullet line
- Maximum 2 nesting levels — no exceptions
- BIG STATEMENT, DATA CALLOUT, FULL IMAGE, and CLOSING CTA: no bullets — use the
  layout's native content format as shown in the wireframe

### One Idea Per Slide

- One title, one message per slide
- Slide title containing "and" joining two distinct concepts: flag and split before building

### Metrics and Numbers

- Preserve exact figures — never round, never generalize
- Format key numbers prominently (large callout size, accent color)
- "Many" / "most" / "significant" are forbidden when a real number exists or can be sourced

### Speaker Notes Extraction

When working from source content that includes speaker notes or presentation scripts:

Discard: Delivery cues, timing notes, filler transitions, "welcome everyone" openers.

Surface to slides: Powerful stats cited only in notes, key objections, strong audience
questions, specific examples that ground abstract points.

---

## Phase 4: Layout Variety Rules

### Visual Pacing (Mandatory)

1. No 3 consecutive slides with the same layout type
2. BULLETS capped at 30% of total deck slides — if exceeded, redistribute to DATA CALLOUT,
   TWO-COLUMN, or PROCESS as appropriate
3. Every 8-slide deck gets at least 1 FULL IMAGE or BIG STATEMENT slide
4. TITLE and CLOSING CTA are exempt from variety counting
5. Dark/light contrast preferred: dark background for TITLE and CLOSING CTA, lighter
   backgrounds for content slides (sandwich structure) — unless user specifies fully dark deck

### SmartArt Selection Logic for PROCESS Slides

Choose the shape that matches how the process actually works — not just what looks good:

| Process Behavior                               | SmartArt Shape  |
|------------------------------------------------|-----------------|
| Steps happen in order, left to right           | Chevron/Arrow   |
| Steps repeat or loop back                      | Cycle/Circle    |
| Volume narrows at each stage                   | Funnel          |
| Each step builds on or elevates the last       | Staircase       |
| One central idea connects to multiple outputs  | Radial/Hub-Spoke|

The wireframe must show the chosen shape in ASCII before the build begins.

---

## Phase 5: Professional Voice Standards

### Language Rules

- Concrete before abstract — example, stat, or before/after lands before the principle
- Specific over vague — "57% of employees" not "many employees"
- Active construction — "Your team uses AI daily" not "AI adoption is achieved"
- No em dashes — use commas, periods, or parentheses instead
- Forbidden AI filler constructions:
    "It is worth noting"
    "It is important to remember"
    "In conclusion"
    "Notably" / "Certainly"
    "Leveraging [X] to optimize [Y]"
    Stacked superlatives: "incredibly powerful, highly effective" (pick one or cut both)

### Slide Title Rules

- Written as outcomes or statements, not topic labels
    Good:  "What 57% of Your Staff Are Already Doing"
    Avoid: "Staff AI Usage Statistics"
- Maximum 8 words
- Sentence case, not Title Case For Every Word
- No end punctuation except when a question is intentional

### Closing Slide Rule

Forward momentum — a specific next action. Not "Thank You." Not an open-ended question.
The closing slide tells the audience what happens next, not what just happened.

---

## Phase 6: File Generation

Once blueprint, wireframes, and theme are all approved:

1. Read /mnt/skills/public/pptx/SKILL.md — follow its creation, design, and QA
   instructions in full
2. Apply approved theme (palette, typography, visual motif) to all slides
3. Apply layout types and wireframe spatial specs from approved blueprint to each slide
4. Implement the SmartArt shape specified in each PROCESS wireframe
5. Apply Phase 3 content rules during content writing
6. Apply Phase 5 voice rules to all generated text
7. Run the pptx skill's mandatory QA loop — visual inspection required before delivery
8. Output file to /mnt/user-data/outputs/[descriptive-deck-name].pptx
9. Deliver via present_files tool

### Build Summary

Include after file delivery:

  Build complete.
    Slides:         X total (note any splits from original blueprint)
    Theme applied:  [Theme Name] -- Primary #XXXXXX / Secondary #XXXXXX / Accent #XXXXXX
    Layout spread:  [e.g., 2x TITLE, 1x BIG STATEMENT, 2x TWO-COLUMN ...]
    SmartArt used:  [e.g., Slide 4: Chevron Process / Slide 7: Basic Cycle]
    Voice flags:    [em dashes caught / vague metrics replaced / titles shortened]
    QA cycles:      [Number of fix-and-verify rounds completed]

---

## Separation from gamma-transformer

|                  | gamma-transformer              | slide-deck                           |
|------------------|--------------------------------|--------------------------------------|
| Input            | Fully-specified slide content  | A goal, topic, or raw content        |
| Process          | Format conversion to markdown  | Blueprint + wireframes + file build  |
| ASCII role       | None                           | Mandatory Phases 1 and 2             |
| Wireframes       | None                           | Per-slide spatial pictures           |
| SmartArt         | Not specified                  | Chosen and drawn in wireframe        |
| Theme selection  | Not included                   | Phase 2, user-approved               |
| Output           | Markdown for Gamma's AI        | .pptx file                           |
| Design control   | Gamma's AI decides layout      | Skill assigns, wireframes, enforces  |
| Triggered by     | "transform for Gamma"          | "build a deck / make a PowerPoint"   |

---

## Pre-Delivery Checklist

Before delivering any deck, confirm:

- [ ] Blueprint overview shown and approved (or user explicitly skipped)
- [ ] Per-slide wireframes shown and approved for all non-trivial slides
- [ ] SmartArt shape selected and shown in wireframe for every PROCESS slide
- [ ] Theme shown and approved (or user explicitly skipped)
- [ ] No slide exceeds 50 words
- [ ] No 3 consecutive slides share a layout type
- [ ] BULLETS layout is 30% or fewer of total slides
- [ ] All exact metrics preserved with original numbers
- [ ] No em dashes anywhere in slide text
- [ ] No AI filler constructions anywhere in slide text
- [ ] All slide titles are 8 words or fewer
- [ ] Closing slide ends with a forward action, not "Thank You"
- [ ] pptx skill QA loop completed with visual inspection
- [ ] Build summary delivered alongside the file
