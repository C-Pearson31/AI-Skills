---
name: optimize-instructions
description: Analyzes correction patterns across all accessible conversations and memory to rewrite a Project's instructions into a smarter, more precise version. Invoke this skill whenever the user asks Claude to review, improve, audit, or evolve its project instructions — including phrases like "review your instructions", "analyze how you're responding", "improve your instructions", "run instruction audit", "optimize your behavior", "what patterns do you notice in my corrections", "update your project instructions", or any request for Claude to self-improve based on past interactions. This skill produces a single ready-to-paste codeblock containing the full rewritten instruction set. Use it aggressively — if the user is asking Claude to get better at responding to them, this skill applies.
---

# optimize-instructions

Performs a deep cross-conversation analysis of correction patterns and rewrites the current Project's instructions into an evolved, more precise version. Output is always a single codeblock the user can paste directly over their existing instructions.

---

## Execution Model

This skill executes a 5-step pipeline. Do not stop between steps. Do not ask for confirmation mid-run. Do not output anything until Step 5 produces the final codeblock.

The only acceptable outputs from this skill are:
1. The complete rewritten instruction set inside a single codeblock
2. One changelog line immediately after the codeblock
3. A brief (2–3 sentence) summary of the most impactful changes — after the changelog

---

## STEP 1 — Establish Diagnostic Baseline

Read the current Project instructions in full before doing anything else.

- Every existing rule is a **hypothesis to be validated**, not a truth to be preserved
- Catalog each rule: what behavior it's trying to enforce, how specific it is, whether it's imperative or vague
- Flag any rules that are: duplicated, overly broad, contradicted by observed behavior, or missing enforcement teeth
- Hold this catalog in working memory — it becomes your comparison baseline in Step 4

If no project instructions exist yet (this is a first run), note that and proceed — Steps 2 and 3 will still surface the user's actual preferences from their correction history.

---

## STEP 2 — Infer Domain Query Terms

Before running any retrieval, scan the current project instructions and any project knowledge files to extract domain-specific vocabulary. This makes retrieval portable across any Project rather than relying on hardcoded generic terms.

Build two query lists:

**Correction Signal Queries** (run on every Project):
- "don't", "wrong", "not what I asked", "too long", "rewrite", "instead", "actually", "that's not"
- "format", "shorter", "simpler", "structure", "bullet", "header"
- "tone", "too formal", "too casual", "hedging", "stop saying"

**Domain Queries** (infer from project context — examples):
- If Salesforce context detected: "Salesforce", "SFDC", "apex", "flows", "admin"
- If AI/consulting context detected: "Claude", "consulting", "AI", "agent", "prompt"
- If writing/content context detected: "post", "draft", "LinkedIn", "voice", "edit"
- Add 2–4 domain terms specific to this Project's apparent focus area

---

## STEP 3 — Cross-Conversation Retrieval

Retrieve broadly. Do NOT limit to the current session.

Execute ALL of the following — do not skip any:

### 3a. Conversation Search (run each as a separate call)
Run `conversation_search` using the Correction Signal Queries from Step 2 — at minimum:
- Pass 1: "don't", "wrong", "not what I asked", "rewrite"
- Pass 2: "format", "shorter", "structure", "bullet", "header"  
- Pass 3: "tone", "too formal", "stop saying", "too long"
- Pass 4: 2–3 domain-specific terms identified in Step 2

### 3b. Recent Chats Scan
Run `recent_chats` with n=15. Scan for **implicit corrections** — moments where the user:
- Redirected mid-thread ("actually, let's do it this way instead")
- Rewrote your output themselves before using it
- Expressed dissatisfaction without a direct command
- Asked the same question multiple ways (signals the first answer missed)

### 3c. Memory Review
Read all active memory entries for this user. Surface:
- Any stated preferences about response style, format, or depth
- Professional context that should calibrate technical level
- Prior corrections already encoded as behavioral notes
- Recurring topics that suggest consistent context Claude should assume

### 3d. Consolidate Findings
Before Step 4, produce an internal working list of every correction signal found, tagged by source (conversation_search / recent_chats / memory) and session proximity (recent = last 7 days / historical = older).

---

## STEP 4 — Pattern Classification and Rule Diagnosis

For each correction signal found, classify it against the baseline rules from Step 1:

| Tag | Definition |
|-----|-----------|
| `FORMAT` | Length, bullet use, header abuse, structural choices |
| `TONE` | Hedging, affirmations, formality level, AI self-reference |
| `DEPTH` | Technical calibration wrong, too shallow, too verbose |
| `ASSUMPTION` | Wrong context inferred, intent misread, wrong audience assumed |
| `MISSING` | Something the user consistently adds back after receiving output |
| `RULE GAP` | Corrected behavior with NO existing rule covering it |
| `WEAK RULE` | Corrected behavior where a rule exists but was too vague to hold |
| `⚠️ REPEAT` | Same pattern appearing across 2+ sessions — HIGHEST PRIORITY |

Then for each rule in the Step 1 baseline, make one of four verdicts:
- **KEEP** — No violation evidence, rule is working
- **STRENGTHEN** — Violations exist, but rule is present and just needs more specificity or force
- **REPLACE** — Rule exists but is fundamentally wrong or counterproductive
- **REMOVE** — Rule is redundant, duplicated, or has no grounding in observed behavior

For each RULE GAP, draft a new rule. Use imperative language only: "Always...", "Never...", "When X, do Y..."

---

## STEP 5 — Full Instruction Rewrite and Output

Generate the complete rewritten instruction set. Requirements:

- **Full replacement** — not a diff, not a list of changes. The entire instruction set, start to finish
- **⚠️ REPEAT items go first** in the behavioral rules section
- All rules use imperative language ("Always", "Never", "When X, do Y")
- STRENGTHEN verdicts produce tighter, more specific rule language
- RULE GAPs become new rules
- REMOVE verdicts are dropped silently (no need to explain what was cut)
- Structure and section headers from the original are preserved unless restructuring improves clarity
- The Changelog section at the bottom is updated with a new entry (not replaced — appended)

### Output Format

Produce in this exact order:

1. The complete rewritten instruction set inside a single fenced codeblock
2. Immediately after the codeblock, one changelog line:
   `[Date] — [# rules added] — [# rules changed] — [# rules removed] — [Top pattern corrected] — [# conversations analyzed]`
3. A 2–3 sentence plain-English summary of the most impactful changes made and why

**No commentary before the codeblock. No preamble. No "here is your updated instruction set." Start with the codeblock.**

---

## Portable Instruction Template

When writing the rewritten instructions, ensure the output includes these structural sections (adapt content, preserve structure):

```
# [Project Name] — Instructions

## Context
[Who the user is, their professional domain, technical level, and primary use cases for this Project]

## Core Behavioral Rules
[⚠️ REPEAT violations first, then all other rules in imperative form]

## Response Format Standards
[Specific formatting rules: when to use bullets, headers, length targets, structure preferences]

## Domain Calibration
[Technical depth expectations, assumed knowledge, vocabulary register]

## Anti-Patterns
[Explicit list of what NOT to do — things the user has repeatedly corrected]

## Changelog
<!-- Entries appended after each audit run -->
```

---

## Reference Files

- `references/chatgpt-variant.md` — Equivalent audit process adapted for ChatGPT Projects (manual data prep required)
- `references/rule-writing-guide.md` — Principles for writing strong, enforceable behavioral rules

Read these only if explicitly asked or if the context requires it.
