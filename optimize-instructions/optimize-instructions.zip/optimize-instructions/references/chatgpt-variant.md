# ChatGPT Variant — Instruction Audit Process

ChatGPT cannot search past conversations automatically. Cross-conversation retrieval requires manual data preparation before the audit runs. This is a fundamental architectural difference from Claude — not a limitation to work around, but a different workflow to follow deliberately.

---

## Trigger Phrase
"run instruction audit"

---

## Pre-Audit Data Preparation (required before triggering)

Choose one method based on audit depth needed:

### Method A — Memory Audit (lightweight, 5 minutes)
1. Go to **Settings > Personalization > Manage Memory**
2. Copy the full memory contents
3. Paste into the chat with the message: "Here is my memory export. Run instruction audit."

Use when: Quick calibration, no major corrections to surface, recent sessions only.

### Method B — Conversation Export (deep audit, 15–20 minutes)
1. Go to **Settings > Data Controls > Export Data**
2. Download and locate `conversations.json`
3. Extract relevant conversations (sessions where corrections were made)
4. Upload the file(s) to this Project's knowledge base
5. Then trigger: "Run instruction audit using the uploaded conversation files."

Use when: Major instruction overhaul, patterns spanning many months, first-time deep audit.

### Method C — Quick Audit (current session only)
Type: "run quick audit"
No data prep needed. Analyzes only the current conversation.

Use when: Immediate post-session cleanup after a dense correction-heavy chat.

---

## Execution Pipeline (mirrors Claude version after data is loaded)

### Step 1 — Read Current Instructions
Read the project instructions as the diagnostic baseline. Every rule is a hypothesis.

### Step 2 — Scan Provided Data for Correction Signals
Search the memory export or uploaded files for:
- Explicit: "don't", "wrong", "not what I asked", "too long", "rewrite", "instead", "actually"
- Implicit: redirections, rewrites, repeated questions, expressed dissatisfaction

Flag any pattern appearing in BOTH the memory export AND uploaded files as `⚠️ REPEAT`.

### Step 3 — Classify Patterns
Use the same classification tags as the Claude version:
FORMAT / TONE / DEPTH / ASSUMPTION / MISSING / RULE GAP / WEAK RULE / ⚠️ REPEAT

### Step 4 — Full Instruction Rewrite
Same requirements as Claude version:
- Complete replacement, not a diff
- ⚠️ REPEAT items first
- Imperative rule language throughout
- Output in a single fenced codeblock

### Step 5 — Output
Codeblock → Changelog line → 2–3 sentence summary

---

## Key Difference from Claude

Claude actively retrieves conversations via tool calls — the entire pipeline is automated from the trigger phrase alone. ChatGPT requires you to surface the data manually first. Neither is superior — they reflect different platform architectures. The quality of the audit on either platform is determined by the breadth of correction data fed into Step 2.
