# Rule Writing Guide — Strong, Enforceable Behavioral Rules

The quality of an instruction set is determined not by how many rules it contains, but by how precisely each rule constrains behavior. A vague rule is functionally no rule at all.

---

## The Four Properties of an Enforceable Rule

### 1. Imperative Voice
Rules must use command language, not preference language.

| Weak | Strong |
|------|--------|
| "Try to keep responses concise" | "Default to prose under 150 words for simple questions" |
| "Be direct" | "Lead with the answer. Place reasoning and context after it, never before." |
| "Avoid being too formal" | "Never open with 'Certainly', 'Absolutely', 'Great question', or any affirmation." |

### 2. Observable Outcome
A rule is enforceable only if a third party could look at a response and determine whether the rule was followed.

Bad: "Be helpful and accurate"
Good: "When asked about Salesforce configuration, specify the org edition and API version assumptions before answering."

### 3. Appropriate Specificity
Over-specific rules break on edge cases. Under-specific rules don't constrain anything.

Bad (too broad): "Format responses well"
Bad (too narrow): "Use exactly 3 bullet points when listing options"
Good: "Use bullet points only when listing 4 or more discrete items with no natural prose connective. For 3 or fewer items, write as a sentence."

### 4. No Internal Contradiction
Scan the full rule set before publishing. Common contradictions:
- "Be concise" + "Always explain your reasoning" — which wins?
- "Use headers for complex topics" + "Avoid headers" — ambiguous trigger condition
- "Match my technical level" + "Always define acronyms" — may conflict for expert users

Resolution: add a tiebreaker ("When X and Y conflict, prefer X") or collapse the rules into one.

---

## Rule Strength Spectrum

From weakest to strongest:

1. **Aspiration** (not a rule): "Aim to be concise"
2. **Preference** (weak): "Prefer shorter responses"
3. **Default with override** (moderate): "Default to prose unless the user explicitly asks for bullets"
4. **Conditional command** (strong): "When a response exceeds 300 words, restructure — the excess is almost always preamble or repetition that can be cut"
5. **Absolute** (strongest): "Never reproduce affirmations. No exceptions."

Use Absolute rules sparingly — only for behaviors the user has corrected multiple times with no acceptable exceptions observed.

---

## Anatomy of a Well-Structured Rule Set

```
## Anti-Patterns (what never to do — absolute rules go here)
- Never open with praise, affirmations, or AI self-reference
- Never add disclaimers to straightforward technical answers

## Format Rules (when/how to structure output)
- Default to prose for responses under 4 distinct points
- Use headers only when a response has 3+ distinct sections the user would want to navigate

## Depth Calibration (technical register)
- Assume [domain] practitioner knowledge — skip foundational definitions unless asked
- When multiple approaches exist, compare them in 2–3 sentences before recommending

## Conditional Rules (trigger-based behavior)
- When the user's question is ambiguous, state your interpretation before answering — don't ask for clarification first
- When corrected, acknowledge the correction in one sentence and proceed — no elaboration
```

---

## Red Flags in Existing Instructions

Look for these patterns when auditing an existing instruction set:

- **Ghost rules**: rules that existed for an old behavior pattern that no longer applies
- **Pile-on rules**: 3+ rules saying the same thing in slightly different ways (consolidate to one strong rule)
- **Untriggered conditionals**: "When X, do Y" where X never actually occurs in this Project
- **Aspirational filler**: "Always strive to...", "Try to...", "Aim for..." — these are not rules
- **Vague scope**: "Be professional" — professional compared to what baseline, in what context?

When you find these, remove or replace. A shorter, tighter instruction set outperforms a long, vague one every time.
