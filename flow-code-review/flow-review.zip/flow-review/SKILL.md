---
name: flow-review
description: review salesforce flow definitions in xml, json, tables, or narrative against a pmd-inspired quality gate. use when a user wants a salesforce flow assessed for quality, bulk safety, fault handling, security/run context, recursion, naming, testability, or governance, especially for metadata api xml or exported flow definitions. produce evidence-based findings, never invent missing metadata, prefer flow-native fixes over apex, and return a structured markdown review with severity, evidence, risks, fixes, a prioritized plan, and targeted follow-up questions only when source gaps block a verdict.
---

# Flow Review

Review Salesforce Flow definitions with strict evidence discipline. Treat Metadata API XML as the source of truth when available. Prefer Flow-native fixes; recommend Apex only when Flow cannot reasonably satisfy the requirement.

## Workflow

Follow this sequence:

1. **Normalize the input**
   - Accept Metadata API XML, tool/custom JSON, an element table, screenshots converted to text, or narrative.
   - If multiple flows are provided, review one flow at a time unless the user explicitly asks for portfolio-level triage.
   - If the input is massive or incomplete, give the best evidenced partial review and say what could not be proven.

2. **Set evidence boundaries**
   - Never invent metadata, element names, fault paths, run mode, trigger order, or test coverage.
   - If a rule cannot be proven from the input, mark it **⚠️** and say **Needs info** in the evidence.
   - Ask only the minimum follow-up questions needed to unblock a verdict, with a hard cap of 8 questions.

3. **Identify the basics**
   - Capture flow name, status, API version, flow type, trigger timing, object, entry criteria, and run context if the source shows them.
   - Determine whether the flow is record-triggered, screen, autolaunched, scheduled, platform event-triggered, or another type.
   - For record-triggered flows, identify before-save vs after-save and the “when to run” behavior when evidenced.

4. **Build an execution map**
   - Inventory major elements/resources and infer the main path and fault paths.
   - Look for loops, Gets, Decisions, Assignments, DML-like elements, Subflows, Apex actions, Callouts, and Custom Error / rollback behavior.
   - Note where the source appears incomplete or out of sync, especially when connectors reference missing elements.

5. **Apply the rule catalog**
   - Use `references/rule-catalog.md`.
   - Evaluate rules in P0 → P1 → P2 order.
   - Include concise evidence, user-facing risk, and the most direct fix.
   - Include at least one short **Violation ex:** for every rule row.

6. **Produce the final report**
   - Use the output structure below.
   - Keep the tone audit-like, direct, and practical.
   - For naming/readability checks, also consult `references/naming-style-guide.md`.

## Output Structure

Use this markdown structure unless the user explicitly asks for a different format:

1. **Scope summary**
   - 1–2 lines.
   - Name the flow, type/timing, object when known, status, API version, and the highest-value conclusion.

2. **Context**
   - Small table with exactly these columns:
     - `Experts`
     - `Categories reviewed`

3. **Results**
   - Table with exactly these columns:
     - `Rule`
     - `Sev`
     - `Status`
     - `Evidence`
     - `Risk`
     - `Fix`
   - Status values: `✅`, `⚠️`, `❌`
   - Severity values: `P0`, `P1`, `P2`
   - Put the violation example in the **Risk** column using this style: `**Violation ex:** ...`

4. **Prioritized fix plan**
   - Group by `P0`, then `P1`, then `P2`.
   - Include concrete retest notes.

5. **Optional Mermaid snippet**
   - Include only when a small diagram clarifies the risky slice.
   - Keep it short and focused on the path under review.

6. **Follow-up**
   - Ask questions only where uncertainty blocks a verdict.
   - Maximum 8 questions.

See `references/output-template.md` for a stronger formatting pattern.

## Rating Rules

- **✅ Pass** = the source clearly evidences compliance.
- **⚠️ Warning** = the source shows a risk, or the rule cannot be proven.
- **❌ Fail** = the source clearly shows a violation.
- **P0** = blocker before production.
- **P1** = major; either fix or justify with mitigation.
- **P2** = minor improvement or hygiene item.

## Evidence Standards

Use these wording rules consistently:

- If the metadata proves the point, say so directly.
- If the user clarified something that is not visible in source, explicitly distinguish confirmation from source evidence. Example: `You confirmed fail closed via Custom Error, but that element is not present in the provided metadata.`
- If the file seems incomplete, say that the review can confirm intent but not full implementation wiring.
- When the source is narrative-only, lower certainty and ask for the metadata export if the verdict matters.

## Flow-Native Fix Guidance

Prefer these fixes first:

- Move repeated or shared logic into subflows when it reduces complexity.
- Replace per-item work with collection-based work.
- Use start criteria and prior-value gating to reduce unnecessary runs.
- Add fault connectors to a real handler.
- Use Custom Error or rollback when integrity requires fail closed.
- Externalize org-specific values into configuration.
- Recommend Apex only when Flow cannot meet scale, determinism, or maintainability requirements.

## Naming and Readability Addendum

Use the naming guide as a secondary standard for readability findings:

- Prefer the `{ALL_CAPS_VERB} {Target Description} [BusinessUnit] [Trigger Context]` flow-name pattern when it fits the org’s convention.
- Avoid version numbers in flow names.
- Include trigger context only when it helps disambiguate.
- Prefer singular nouns unless the flow genuinely handles multiples.
- Favor business-meaningful labels over generic names like `Decision1`, `Assignment2`, `Yes`, or `No`.

## Large or Ambiguous Inputs

- If the user provides many flows, recommend splitting by flow and still deliver a best-evidenced partial review.
- If bulk/limit risk depends on data volume, ask for record counts and selection criteria.
- If the user asks for a terse answer, keep the same structure but shorten evidence and fixes.

## Slash Commands

Interpret these commands when the user uses them:

- `/help` → explain what inputs work and what output to expect.
- `/review` → run the full review.
- `/summary` → give only scope summary + top fixes.
- `/q` → ask only the minimum follow-up questions needed.
- `/redo` → rerun with updated evidence.
- `/more` → expand rationale and alternatives.
- `/links` → add 2–5 official Salesforce links when useful.
- `/alt` → propose an alternative design.
- `/arg` → argue both sides of a borderline rule call.
