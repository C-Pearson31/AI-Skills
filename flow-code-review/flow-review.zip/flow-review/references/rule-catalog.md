# Rule Catalog

Apply rules in this order: P0, then P1, then P2.

## P0 Blockers

### FLOW-P0-001 Description required
- Check whether the flow description is populated and useful.
- Pass only when the description explains purpose, trigger/timing, and the failure strategy at a useful level.
- Common failure: empty description, placeholder text, or vague text like `TBD`.
- Preferred fix: use a concise template covering purpose, trigger/timing, entry criteria, DML impact, dependencies, fail-closed/open strategy, owner, and change log.

### FLOW-P0-002 Selective Start + correct “When to Run”
- For triggered flows, verify the flow does not run more often than necessary.
- Look for changed-field gating, precise criteria, and correct timing semantics.
- Common failure: runs on every update, or start criteria do not align to the responsibility.
- Preferred fix: tighten criteria, use prior-value gating, or split responsibilities into separate flows.

### FLOW-P0-003 No DML in loops
- Look for create/update/delete operations inside an iteration path.
- Common failure: update/create/delete inside a loop.
- Preferred fix: accumulate records in collections and perform one DML operation after the loop.

### FLOW-P0-004 No Get Records in loops
- Look for record lookups that occur per item in a loop.
- Common failure: a Get Records element on the loop path.
- Preferred fix: query once, store records, and filter in memory or restructure to set-based logic.

### FLOW-P0-005 Fault paths on risky elements
- Risky elements include DML-like operations, Apex, subflows, external actions/callouts, and Gets when failure matters.
- Common failure: no fault connector, or a fault connector that silently dead-ends.
- Preferred fix: add a real fault handler that either blocks the transaction or logs/notifies intentionally.

### FLOW-P0-006 Explicit failure strategy (Fail Closed vs Fail Open)
- Determine whether the design intentionally blocks save/commit or intentionally logs and continues.
- Common failure: fault handling exists but the transaction outcome is ambiguous or contrary to data-integrity needs.
- Preferred fix: use Custom Error / rollback for fail closed, or explicit log + notify for fail open.

### FLOW-P0-007 Recursion / re-entry guard
- Check whether the flow can trigger itself or create ping-pong automation.
- Common failure: after-save updates the same record/fields without prior-value or processed-state guards.
- Preferred fix: prior-value guard, processed flag/timestamp, or better separation of before-save vs after-save responsibilities.

### FLOW-P0-008 No hard-coded IDs / org-specific constants
- Look for raw Salesforce IDs or brittle org-specific constants in formulas, decisions, assignments, or routing.
- Common failure: hard-coded user, queue, or record type IDs.
- Preferred fix: configuration via custom metadata/settings, or lookups by stable developer names.

### FLOW-P0-009 Security/run context must be justified
- Determine whether user mode vs system mode is visible and appropriate.
- Common failure: system mode touches sensitive data without guardrails or clear business justification.
- Preferred fix: least privilege, explicit permission checks, and documentation of why elevated context is necessary.

### FLOW-P0-010 Testability gate
- Ask whether there is evidence of flow tests, Apex tests, CI validation, or other production-ready test coverage.
- Common failure: only manual or production testing is mentioned.
- Preferred fix: flow tests covering happy path, bulk behavior, negative cases, and fault paths.

### FLOW-P0-011 Trigger order governance
- Check whether multiple flows on the same object/timing could conflict.
- Common failure: two or more flows write the same field without explicit order or orchestration.
- Preferred fix: trigger order, orchestrator flow + subflows, or consolidated ownership of the field.

## P1 Majors

### FLOW-P1-101 Complexity budget
- Evaluate branching, cross-links, and readability of the path graph.
- Common failure: spaghetti flow with many outcomes and cross-connected paths.
- Preferred fix: split by responsibility, use subflows, or drive rules from configuration.

### FLOW-P1-102 Nested loops
- Look for a loop inside another loop.
- Common failure: parent loop followed by child loop in-path.
- Preferred fix: flatten the design, pre-group data, or pre-query relationships.

### FLOW-P1-103 High element/limit footprint
- Look for repeated Gets, repeated DML, or many heavy elements for the likely volume.
- Common failure: repeated queries of equivalent data or multiple update blocks on the same records.
- Preferred fix: consolidate queries, reuse collections, and collapse DML.

### FLOW-P1-104 Unused resources removed
- Identify formulas, variables, constants, or resources that are never referenced.
- Common failure: dead resources left after refactors.
- Preferred fix: delete unused resources or rename/document them if they are intentionally reserved.

### FLOW-P1-105 Screen flow DML between screens
- For screen flows, check whether commits happen mid-interview.
- Common failure: screen → DML → screen, which can duplicate actions on back/exit.
- Preferred fix: gather inputs first, confirm, then commit once at the end with rollback strategy as needed.

### FLOW-P1-106 Old API version
- Note when the API version is materially old and there is no reason given.
- Common failure: very stale API version with no regression plan.
- Preferred fix: upgrade in sandbox and regression test before release.

### FLOW-P1-107 Context mismatch (wrong type/timing)
- Check whether the flow type/timing matches the work being done.
- Common failure: before-save flow orchestrates related records, or record-triggered flow is used for batch-style workloads.
- Preferred fix: move work to after-save, scheduled, async, or split responsibilities.

### FLOW-P1-108 Parallel/async race + lock risk
- Check whether multiple branches or async paths could contend for the same rows or fields.
- Common failure: multiple writers to the same records concurrently.
- Preferred fix: single-writer rule, sequencing, or consolidated updates.

### FLOW-P1-109 Naming/readability
- Review flow name, element names, outcome names, and general readability.
- Common failure: generic labels like `Decision1`, `Assignment2`, `Yes`, or `No`.
- Preferred fix: business-meaningful names and alignment to the org naming guide.

## P2 Minors

### FLOW-P2-201 Modularize/reuse via subflows
- Identify repeated logic or repeated error handling that should be centralized.
- Common failure: copy-pasted logic across flows.
- Preferred fix: shared subflows with clear inputs/outputs.

### FLOW-P2-202 Externalize configuration
- Identify hard-coded business thresholds, routing values, or environment-specific strings that change over time.
- Common failure: thresholds or email addresses embedded in formulas.
- Preferred fix: custom metadata or similar configuration.

### FLOW-P2-203 Inline docs for complex nodes
- Check whether complex decisions/loops have enough inline description to explain intent or scale assumptions.
- Common failure: complex branch logic with no annotation.
- Preferred fix: short descriptions on complex elements.

### FLOW-P2-204 Versioning hygiene/change log
- Check whether the description captures ownership and change traceability.
- Common failure: no owner, ticket, or change notes.
- Preferred fix: append date, ticket, summary, and reviewer in the description or governed documentation.
