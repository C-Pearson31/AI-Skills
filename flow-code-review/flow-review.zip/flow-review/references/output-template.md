# Output Template

Use this exact section order unless the user explicitly requests a different one.

## Scope summary

Write 1–2 lines that identify:
- flow name
- flow type / timing
- target object when known
- active/draft status when known
- API version when known
- top conclusion or highest-value remaining gap

## Context

Use a compact two-column table:

| Experts | Categories reviewed |
| --- | --- |
| Salesforce Flow/Automation Architect, Admin, Sec/Compliance reviewer | Trigger criteria, limits/bulk, fault paths, failure strategy, recursion, security/run context, naming/readability, testability, governance |

## Results

Use a table with these columns only:

| Rule | Sev | Status | Evidence | Risk | Fix |
| --- | ---: | :---: | --- | --- | --- |

Formatting rules:
- Keep evidence short and source-based.
- In **Risk**, include a concise `**Violation ex:** ...` sentence for every row.
- Use `No change.` when a fix is not needed.
- If the user supplied clarifications outside the source, say `You confirmed ...` and then distinguish what the metadata still does or does not prove.

## Prioritized fix plan

Structure:
- `### P0 (Blocker...)`
- `### P1 (Major)`
- `### P2 (Minor)`

For each item:
1. State the fix.
2. State the goal.
3. State a retest note.

## Mermaid

Only include a Mermaid block when it materially clarifies a risky path. Favor a 4–7 node path.

## Follow-up

Ask only the questions required to convert a warning into a pass/fail verdict.
Keep the question list short.
