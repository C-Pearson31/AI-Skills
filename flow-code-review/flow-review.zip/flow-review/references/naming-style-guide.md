# Salesforce Flow Naming Style Guide

Use this guide as the readability standard when the org wants naming aligned to a consistent Flow convention.

## Flow naming pattern

Preferred pattern:

`{ALL_CAPS_VERB} {Target Description} [BusinessUnit] [Trigger Context]`

Definitions:
- `ALL_CAPS_VERB`: action that best describes what the flow does.
- `Target Description`: plain-English summary of the object or outcome.
- `[BusinessUnit]`: bracketed business-unit marker when applicable.
- `[Trigger Context]`: optional disambiguator such as `After Insert`, `On Schedule`, or `Screen Flow`.

## Approved verb set

Preferred verbs from the guide:
- `CREATE`
- `UPDATE`
- `POPULATE`
- `ASSOCIATE`
- `SEND`
- `SCHEDULE`
- `REVERT`
- `DETECT`
- `SET`

## Best practices

Use these as review criteria:
- Avoid version numbers in flow names.
- Include trigger timing only when it helps distinguish the flow.
- Prefer singular terms unless the flow explicitly handles multiple items.
- Favor names that communicate business intent immediately to admins, analysts, and developers.

## Example renames

- `KSD Multi Event Submission Handler` → `CREATE KSD Multi Events [MS] After Insert`
- `KSD Populate Account` → `POPULATE Account on KSD Record [MS] After Insert`
- `Update Case fields based on web form` → `UPDATE Case Fields from Web Form [SVC]`
- `Autopopulate MS Oppty on Key School Dates` → `ASSOCIATE Opportunity to KSD [MS] After Update`
- `MCDM Schedule Send Flow` → `SCHEDULE Marketing Sends [MCDM]`
- `Is Picture Day Coordinator V.009` → `DETECT Picture Day Coordinator [YBK] After Insert`

## How to use in reviews

- Apply primarily to `FLOW-P1-109 Naming/readability`.
- Mention misalignment as a readability/governance issue, not a platform runtime defect.
- When recommending a rename, preserve the business meaning and only include trigger context if it genuinely disambiguates the flow.
